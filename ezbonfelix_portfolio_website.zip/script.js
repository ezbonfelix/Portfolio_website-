function greetUser() {
  const greetingElement = document.getElementById('greeting');
  const hour = new Date().getHours();
  let greeting = '';
  if (hour < 12) greeting = 'Good Morning!';
  else if (hour < 18) greeting = 'Good Afternoon!';
  else greeting = 'Good Evening!';
  if (greetingElement) greetingElement.textContent = greeting;
}

function validateContactForm() {
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phonePattern = /^\d{10}$/;
  if (!emailPattern.test(email)) {
    alert('Please enter a valid email address.');
    return false;
  }
  if (!phonePattern.test(phone)) {
    alert('Please enter a 10-digit phone number.');
    return false;
  }
  return true;
}

function toggleDetails(button) {
  const details = button.nextElementSibling;
  if (details.style.display === 'none') {
    details.style.display = 'block';
    button.textContent = 'Hide Details';
  } else {
    details.style.display = 'none';
    button.textContent = 'Show Details';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = 'Toggle Theme';
  document.body.appendChild(toggleBtn);
  toggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });
});
