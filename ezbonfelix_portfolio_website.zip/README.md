# Personal Portfolio Website

This is my personal portfolio website built using **HTML**, **CSS**, and **JavaScript**. It showcases my projects, skills, and provides a way to contact me. It was created as part of **CP 221 Practical Assignment One**.

## Live Demo

[View Live Website](https://ezbonfelix.github.io/portfolio-website/)

## Features

- Multi-page website with:
  - Home
  - About Me
  - Projects
  - Contact Form
  - Survey Form
- Semantic HTML5 and responsive layout
- JavaScript features:
  - Greeting message based on time of day
  - Form validation (email, phone)
  - Dark/Light mode toggle
  - Show/Hide project details
- Accessibility best practices
- Embedded YouTube video and image links

## Tools Used

- HTML5
- CSS3 (Flexbox, layout, styling, media queries)
- JavaScript (DOM, events, regex)
- GitHub Pages for deployment

## Challenges Faced

- Making the form validations user-friendly with JavaScript
- Ensuring responsiveness on different screen sizes
- Managing theme toggle and user preferences

## How to Run Locally

1. Download or clone the repo:
   ```bash
   git clone https://github.com/ezbonfelix/portfolio-website.git
   ```
2. Open `index.html` in your browser.

## Author

Ezbon Felix — CP 221 Student
